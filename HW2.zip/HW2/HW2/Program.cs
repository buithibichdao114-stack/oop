﻿using System;

namespace HW2
{
    public class Person
    {
        private string name;
        private string address;
        private double salary;

        // Constructor không tham số
        public Person() { }

        // Constructor đầy đủ tham số
        public Person(string name, string address, double salary)
        {
            this.name = name;
            this.address = address;
            this.salary = salary;
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        public double Salary
        {
            get { return salary; }
            set { salary = value; }
        }

        // Function 1: Input Person information
        public static Person inputPersonInfo(string name, string address, string sSalary)
        {
            if (string.IsNullOrWhiteSpace(sSalary))
            {
                throw new Exception("You must input Salary.");
            }

            double salary;
            // Kiểm tra xem sSalary có phải là số hợp lệ hay không
            if (!double.TryParse(sSalary.Trim(), out salary))
            {
                throw new Exception("You must input digit.");
            }

            // Kiểm tra lương phải lớn hơn 0
            if (salary <= 0)
            {
                throw new Exception("Salary is greater than zero");
            }

            return new Person(name, address, salary);
        }

        // Function 2: Display Person information
        public static void displayPersonInfo(Person person)
        {
            Console.WriteLine("Information of Person you have entered:");
            Console.WriteLine($"Name: {person.Name}");
            Console.WriteLine($"Address: {person.Address}");
            Console.WriteLine($"Salary: {person.Salary}");
        }

        // Function 3: Sort Person array by salary ascending using Bubble Sort
        public static Person[] sortBySalary(Person[] person)
        {
            if (person == null)
            {
                throw new Exception("Can't Sort Person");
            }

            int n = person.Length;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - i - 1; j++)
                {
                    if (person[j].Salary > person[j + 1].Salary)
                    { 
                        Person temp = person[j];
                        person[j] = person[j + 1];
                        person[j + 1] = temp;
                    }
                }
            }
            return person;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=====Management Person programer====="); 

            Person[] persons = new Person[3]; 

            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Input Information of Person"); 
                
                Console.Write("Please input name: "); 
                string name = Console.ReadLine();

                Console.Write("Please input address: "); 
                string address = Console.ReadLine();

                while (true)
                {
                    Console.Write("Please input salary:"); 
                    string sSalary = Console.ReadLine();
                    try
                    {
                        Person p = Person.inputPersonInfo(name, address, sSalary);
                        persons[i] = p;
                        break;
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                }
            }

            try
            {
                // Sắp xếp danh sách theo lương tăng dần
                Person.sortBySalary(persons);

                // Hiển thị thông tin sau khi sắp xếp
                foreach (Person p in persons)
                {
                    Person.displayPersonInfo(p);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
